$query = "select * from Msft_WmiProvider_OperationEvent where Provider='WmiPerfInst' "
$global:wmi_procdumppid = 0
$global:wmi_provider = 0
logman create trace "base_diagnosis" -ow -o c:\WMIperfInst.etl -p '{970406AD-6475-45DA-AA30-57E0037770E4}' 0xffffffffffffffff 0xff -nb 16 16 -bs 1024 -mode Circular -f bincirc -max 4096 -ets


function CheckProvider ( [string]$message ) {
    $result = @( $message )
    $p =  (get-wmiobject msft_providers).Where( { $_.Provider -match "WmiPerfInst" }).HostProcessIdentifier
    if ( $p -eq $null ) {
        $result += "No WMIPerfinst provider currently running "
        write-host "No WMIPerfinst provider currently running "
        $global:wmi_provider = 0
    }
    else {
        write-host ""WMIPerfinst provider is $p - previous $global:wmi_provider""
        $result += "WMIPerfinst provider is $p - previous $global:wmi_provider"
        $global:wmi_provider = $p
    }

    $previous = $global:wmi_procdumppid
    if($previous -ne 0  ) {
        $c = get-process -id $global:wmi_procdumppid -ErrorAction SilentlyContinue
        if( $c -eq $null ) {
            $result += "Previous procdump  process $previous doesnt exist anymore "
            $global:wmi_procdumppid = 0
        }
        else {
            $result += "Previous procdump process $previous still exist" 
        }
    }
    if(  ( $global:wmi_provider -ne 0 ) -and ($global:wmi_provider -ne $global:wmi_procdumppid )  ) {
        write-host "Starting procdump $global:wmi_provider "
        $global:wmi_procdumppid = $global:wmi_provider
        $result += "will procdump $global:wmi_provider"
        start-process .\procdump.exe -ArgumentList "-accepteula" , "-mt" ,  "-e" ,  "1" ,  "-n"  , "1000" , $global:wmi_provider
    }

    
    $result | out-file -append "result.txt"
    write-host $result 
}
function CheckMemory {
    $result = @( "--- Checking memory global:wmi_provider  " )
    
    if( $global:wmi_provider -ne 0 ) {
        $r = get-wmiobject Win32_perfRawdata_PerfOs_memory
        [string]$t = [datetime]::now
        if ( $null -eq $r -or ($r.AvailableBytes -eq 0 ) ) {
           
            write-host "stopping ...."
            write-error -ErrorAction Ignore "$t Issue detected "
            $result += "$t issue detected"
            $global:Encore = $false
        }
        else {
            $result += "$t - Win32_perfRawdata_PerfOs_memory ok  "
            write-host "$t - Win32_perfRawdata_PerfOs_memory ok  "
        }
    }
    $result | out-file -append "result.txt"
}
$action =  {
    $global:lastevent = $event 
    $myclass  = $event.SourceArgs.NewEvent.__CLASS
    Write-Host ([datetime]::now) 
	Write-Host $myclass
	If(  $myclass -match "Msft_WmiProvider_LoadOperationEvent|Msft_WmiProvider_UnLoadOperationEvent" ) {
            $result = "{0}  {1} " -f  [datetime]::now , $myclass 
            write-host $result
            CheckProvider -message $result
            CheckMemory;
            
	}
}

$global:encore = $true;
CheckProvider
CheckMemory -message "--------------- Startup "
$global:WMIevent = Register-WmiEvent -SourceIdentifier MonitorProvider -Action $action -Query $query


while ( $global:Encore ) {
    for ( $i = 0 ; $i -lt 900 -and $global:Encore   ; $i++ ) { Start-sleep 1 }
    if(  $global:Encore )  { CheckMemory }
}

Unregister-Event -SourceIdentifier MonitorProvider

logman stop base_diagnosis -ets
write-host "Please provide result.txt and c:\WMIperfInst.etl"

