get-process | % { c:\debug\tlist.exe  $_.ID } | out-file -append "list.txt"
