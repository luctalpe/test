

function VerifySymbol( [string]$Module = 'c:\Windows\system32\Wbem\WMISvc.dll') {

    Set-Location c:\Debug
    if( -not $(test-path "$Module") ) {
        throw "$Module not found"
    }
    $output =  c:\debuggers\SymChk.exe  /if $module /s c:\debug 
    $notpassed =  ($Output -match "SYMCHK: FAILED files = 1" ).Count
    
    if( $notpassed -gt 0  )  {
        $output = (c:\debuggers\SymChk.exe /v /if "$module" /s "SRV*https://msdl.microsoft.com/download/symbols"  2> "output.txt" )
        $notpassed =  ($Output -match "SYMCHK: PASSED . IGNORED files = 1").Count
        $notpassed 

        $pdbfilename = type "output.txt" | where-object { [string]$_ -match "PdbFileName" } |  ForEach-Object { (([string]$_).split()[-1]).Trim() }
        if( test-path "output.txt" ) { remove-item "output.txt"}
        $pdbfilename

        if( $notpassed -eq  0  ) {
            throw  "Unable to find symbol  file (.pdb) for $module"
        }
        copy-item -verbose $pdbfilename
    }
    else {
        write-host "Using existing pdb in c:\debug"
    }
}

VerifySymbol -Module 'c:\Windows\system32\perfdisk.dll'
VerifySymbol -Module 'c:\Windows\system32\perfos.dll'
VerifySymbol -Module 'c:\Windows\system32\pdh.dll'
VerifySymbol -Module 'c:\Windows\system32\wbem\WMIperfinst.dll'