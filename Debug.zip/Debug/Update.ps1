﻿param (  [string[]] $Hooks32 , [string[]] $Hooks64 , [BOOL]$bRemove = $false ) 

$MyHooksKeys  = @( "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Windows" , "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows NT\CurrentVersion\windows" )
mkdir "c:\debug" -ErrorAction SilentlyContinue
$x86 = "c:\debug\x86"; 
mkdir $x86 -ErrorAction SilentlyContinue
$x64 =  "c:\debug\amd64"; 
mkdir $x64 -ErrorAction SilentlyContinue

function UpdateRegistry ( [BOOL]$x64 = $false  , [string[]] $Hooks , [BOOL]$bRemove  ) {


    if ( $x64  ) {
        $key = $MyHooksKeys[0];
    }
    else {
        $key = $MyHooksKeys[1];
    }
    write-host -BackgroundColor Red -ForegroundColor White @"

***** 
**** Updating  $key 
*****
"@   
    $AppInit = $(Get-ItemProperty -path $key -name AppInit_DLLs).AppInit_DLLs

    write-host -BackgroundColor DarkGreen -ForegroundColor White  "$key  old values ( $AppInit) " 
    Get-ItemProperty $key -name AppInit*,Require*,Load* | Select-Object AppInit*,Require*,Load* | format-list 

    $bChange = $False;
    foreach ( $file in $Hooks ) {
        $b =  "$AppInit" -match [regex]::Escape($file )
        if ( $bRemove -eq $false ) {
            if( $b ) {
                write-host "$file already exist in AppInit_DLLs regsitry value" 
            }
            else {
                if ( $AppInit -eq "" ) {
                    $AppInit = $file;
                }
                else {
                    $AppInit += "," + $file
                }
                $bChange = $true;
                 write-host "$file will be added to AppInit_DLLs registry value " 
            }
        }
        else {
            if( $b ) {
               write-host "$file will be removed from AppInit_DLLs registry value "
               $AppInit = $AppInit -replace [regex]::Escape($file),""
               $AppInit = $AppInit -replace ",,",""
               $bChange = $true;
               if( $AppInit -eq "," ) { $AppInit = ""; }

            }
            else {
                
                write-host "$file dont exist in AppInit_DLLs" 
            }
        }
    }
    if ($bchange ) {
        if( $AppInit -eq "," ) { $AppInit = ""; }
        $AppInit =   $AppInit.Trim();

        write-host -Background  DarkGreen -ForegroundColor White "Setting $key new value ( $AppInit )" 
        set-itemproperty -Path $key -name AppInit_DLLs -value "$AppInit"
        if( $AppInit.Length -eq 0 ) {
            set-itemproperty -Path $key -name RequireSignedAppInit_DLLs -value 1
            set-itemproperty -Path $key -name LoadAppInit_DLLs -value 0
        }
        else {
            set-itemproperty -Path $key -name RequireSignedAppInit_DLLs -value 0
            set-itemproperty -Path $key -name LoadAppInit_DLLs -value 1
        }
        Get-ItemProperty $key -name AppInit*,Require*,Load* | Select-Object AppInit*,Require*,Load* | format-list 
    }
    

}


function CheckRedirected {
    $date = [string][datetime]::Now;
    Set-ItemProperty -Path $MyHooksKeys[0] -Name CheckLUCT -Value "$date" 
    $redirected = $false;
    $c  = Get-ItemProperty -Path $MyHooksKeys[1] -Name CheckLUCT  -ErrorAction SilentlyContinue
    if ($c -eq $null ) { 
        Remove-ItemProperty -Path $MyHooksKeys[0] -Name CheckLUCT 
        return $false; 
    }


    if( $c.CheckLUCT -eq $date ) {
        $redirected = $true
    }
    Remove-ItemProperty -Path $MyHooksKeys[0] -Name CheckLUCT 
    return $redirected
}


# Copy all the files 

$redirected = CheckRedirected

$f32 = @();
$f64 = @();

if( $bremove -eq $false ) {
    write-host -BackgroundColor Red -ForegroundColor White @"

***** 
**** Copying x86 hooks
*****
"@
}



if( $Hooks32.Length -gt 0  ) {
    $Hooks32 | % { 
        if( ($bRemove -eq $False) -and ((test-path $_) -eq $false) )  {
            throw  "Unable to access $_" ;
           
        }
        $dest = "{0}\{1}" -f $x86 , $( split-path $_ -Leaf ); 
        if( $bRemove -eq $False ) {  
             "copying  $_  ==> $dest" ; 
              copy "$_" "$dest"
        }
        if( $redirected) { $f64 += $dest  }
        else { $f32 += $dest }
   } 

}

if( $bremove -eq $false ) { write-host -BackgroundColor Red -ForegroundColor White @"

***** 
**** Copying x64 hooks
*****
"@
}

if( $Hooks64.Length -gt 0 ) {
    $Hooks64 | % { 
        if( ($bRemove -eq $False) -and ((test-path $_) -eq $false) )  {
            throw  "Unable to access $_" ;
           
        }
        $dest = "{0}\{1}" -f $x64 , $( split-path $_ -Leaf ) ; 
        if( $bRemove -eq $False ) {  
            "copying  $_  ==> $dest" ; 
            copy "$_" "$dest"
        }  
        $f64 += $dest 
    }
}


if( $f32.Length -gt 0 ) {
    UpdateRegistry -x64 $false  -Hooks $f32 -bRemove $bRemove
}

if ( $f64.Length -gt 0 ) {
    UpdateRegistry -x64 $true -Hooks $f64 -bRemove $bRemove
}